//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-9dSzoAsd.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-DvWAo0rb.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DvWAo0rb.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CKMRNdwl.js"]
	}
} });
//#endregion
export { tsrStartManifest };
