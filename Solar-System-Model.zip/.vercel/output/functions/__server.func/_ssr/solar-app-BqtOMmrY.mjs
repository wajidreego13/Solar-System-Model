import { i as __toESM } from "../_runtime.mjs";
import { o as require_jsx_runtime, r as Slot, s as require_react } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as Canvas, d as Object3D, f as RepeatWrapping, i as Html, l as CanvasTexture, m as Vector3, n as OrbitControls, o as useFrame, p as SRGBColorSpace, r as Line, s as useThree, t as Stars, u as ClampToEdgeWrapping } from "../_libs/@react-three/drei+[...].mjs";
import { a as Pause, c as CaptionsOff, i as Play, n as Undo2, o as Orbit, s as Captions, t as X } from "../_libs/lucide-react.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { i as SliderTrack, n as SliderRange, r as SliderThumb, t as Slider$1 } from "../_libs/@radix-ui/react-slider+[...].mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/solar-app-BqtOMmrY.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap font-medium transition-[color,background-color,box-shadow,transform,opacity] duration-[var(--motion-quick)] ease-[var(--ease-out)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/70 disabled:pointer-events-none disabled:opacity-40 active:not-disabled:scale-[0.96] [&_svg]:pointer-events-none [&_svg]:shrink-0", {
	variants: {
		variant: {
			default: "bg-primary text-primary-foreground hover:opacity-90",
			ghost: "bg-transparent text-foreground hover:bg-muted/80",
			outline: "bg-transparent text-foreground shadow-[var(--shadow-border)] hover:shadow-[var(--shadow-border-hover)] hover:bg-muted/50",
			subtle: "bg-muted text-foreground hover:bg-muted/80"
		},
		size: {
			default: "h-11 rounded-md px-4 text-sm",
			sm: "h-9 rounded-sm px-3 text-xs",
			icon: "size-11 rounded-md",
			"icon-sm": "size-9 rounded-sm"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, asChild = false, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		ref,
		...props
	});
});
Button.displayName = "Button";
var Slider = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Slider$1, {
	ref,
	className: cn("relative flex h-11 w-full touch-none items-center select-none", className),
	...props,
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderTrack, {
		className: "relative h-1 w-full grow overflow-hidden rounded-full bg-muted",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderRange, { className: "absolute h-full bg-primary" })
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderThumb, { className: "block size-4 rounded-full bg-primary shadow-[var(--shadow-border)] outline-none transition-[box-shadow] duration-[var(--motion-quick)] ease-[var(--ease-out)] focus-visible:ring-2 focus-visible:ring-ring/70" })]
}));
Slider.displayName = Slider$1.displayName;
var BODIES = [
	{
		id: "sun",
		name: "Sun",
		kind: "star",
		kindLabel: "G-type star",
		radius: 2.45,
		orbitRadius: 0,
		eccentricity: 0,
		inclination: 0,
		orbitPeriod: 1,
		spin: .14,
		axialTilt: .13,
		swatch: "#f3d7a1",
		roughness: 1,
		metalness: 0,
		emissive: "#ffd59a",
		emissiveIntensity: 1.4,
		inPicker: true,
		distanceAu: "—",
		diameterKm: "1,392,700 km",
		year: "—",
		day: "25.4 days (eq.)",
		moons: "—",
		summary: "A G-type main-sequence star holding more than 99% of the system's mass. Its gravity writes every orbit in this model."
	},
	{
		id: "mercury",
		name: "Mercury",
		kind: "terrestrial",
		kindLabel: "Terrestrial planet",
		radius: .22,
		orbitRadius: 5.15,
		eccentricity: .21,
		inclination: .12,
		orbitPeriod: 5.2,
		spin: .22,
		axialTilt: .03,
		swatch: "#9a9086",
		roughness: .92,
		metalness: .08,
		inPicker: true,
		distanceAu: "0.39 AU",
		diameterKm: "4,879 km",
		year: "88 days",
		day: "59 days",
		moons: "0",
		summary: "The innermost world. A cratered, airless body that bakes by day and freezes by night, racing the Sun on a markedly eccentric path."
	},
	{
		id: "venus",
		name: "Venus",
		kind: "terrestrial",
		kindLabel: "Terrestrial planet",
		radius: .38,
		orbitRadius: 7.35,
		eccentricity: .007,
		inclination: .059,
		orbitPeriod: 8.6,
		spin: -.07,
		axialTilt: 3.1,
		swatch: "#d9c18a",
		roughness: .78,
		metalness: 0,
		atmosphereColor: "#e6d7a8",
		atmosphereScale: 1.08,
		inPicker: true,
		distanceAu: "0.72 AU",
		diameterKm: "12,104 km",
		year: "225 days",
		day: "243 days (rev.)",
		moons: "0",
		summary: "Earth's dense twin, wrapped in a runaway greenhouse. It spins slowly backwards beneath a pale sulfuric haze."
	},
	{
		id: "earth",
		name: "Earth",
		kind: "terrestrial",
		kindLabel: "Terrestrial planet",
		radius: .4,
		orbitRadius: 10,
		eccentricity: .017,
		inclination: 0,
		orbitPeriod: 12,
		spin: .58,
		axialTilt: .41,
		swatch: "#6ea0d0",
		roughness: .62,
		metalness: .04,
		atmosphereColor: "#8ec5ff",
		atmosphereScale: 1.07,
		inPicker: true,
		distanceAu: "1.00 AU",
		diameterKm: "12,742 km",
		year: "365.25 days",
		day: "23.9 hours",
		moons: "1",
		summary: "The only world known to harbor life. Liquid oceans, wandering continents, and a thin blue atmosphere catch the Sun."
	},
	{
		id: "moon",
		name: "Moon",
		kind: "moon",
		kindLabel: "Natural satellite",
		radius: .12,
		orbitRadius: 1.05,
		eccentricity: .055,
		inclination: .09,
		orbitPeriod: 3.4,
		spin: .18,
		axialTilt: .12,
		swatch: "#c5c1b8",
		roughness: .95,
		metalness: 0,
		parentId: "earth",
		inPicker: false,
		distanceAu: "384,400 km",
		diameterKm: "3,475 km",
		year: "27.3 days",
		day: "27.3 days",
		moons: "—",
		summary: "Earth's companion, tidally locked so the same face always watches home. Its pull lifts the oceans twice a day."
	},
	{
		id: "mars",
		name: "Mars",
		kind: "terrestrial",
		kindLabel: "Terrestrial planet",
		radius: .28,
		orbitRadius: 13.15,
		eccentricity: .093,
		inclination: .032,
		orbitPeriod: 18.2,
		spin: .54,
		axialTilt: .44,
		swatch: "#c48462",
		roughness: .88,
		metalness: .02,
		atmosphereColor: "#d9a078",
		atmosphereScale: 1.05,
		inPicker: true,
		distanceAu: "1.52 AU",
		diameterKm: "6,779 km",
		year: "687 days",
		day: "24.6 hours",
		moons: "2",
		summary: "A cold desert stained with iron oxide. Polar ice, ancient riverbeds, and the tallest volcano in the system remain."
	},
	{
		id: "jupiter",
		name: "Jupiter",
		kind: "gas-giant",
		kindLabel: "Gas giant",
		radius: 1.18,
		orbitRadius: 19.8,
		eccentricity: .049,
		inclination: .023,
		orbitPeriod: 44,
		spin: 1.15,
		axialTilt: .05,
		swatch: "#d0b48a",
		roughness: .55,
		metalness: 0,
		inPicker: true,
		distanceAu: "5.20 AU",
		diameterKm: "139,820 km",
		year: "11.9 years",
		day: "9.9 hours",
		moons: "95",
		summary: "The system's shield. A hydrogen-helium giant whose storms have lasted centuries, including the Great Red Spot."
	},
	{
		id: "saturn",
		name: "Saturn",
		kind: "gas-giant",
		kindLabel: "Gas giant",
		radius: 1.02,
		orbitRadius: 25.8,
		eccentricity: .057,
		inclination: .043,
		orbitPeriod: 66,
		spin: 1.02,
		axialTilt: .47,
		swatch: "#e0d0a8",
		roughness: .58,
		metalness: 0,
		hasRings: true,
		ringInner: 1.35,
		ringOuter: 2.35,
		inPicker: true,
		distanceAu: "9.58 AU",
		diameterKm: "116,460 km",
		year: "29.5 years",
		day: "10.7 hours",
		moons: "146",
		summary: "Pale, banded, and famously ringed. Ice and rock orbit in a paper-thin disk that catches sunlight like a blade."
	},
	{
		id: "uranus",
		name: "Uranus",
		kind: "ice-giant",
		kindLabel: "Ice giant",
		radius: .62,
		orbitRadius: 32.2,
		eccentricity: .046,
		inclination: .013,
		orbitPeriod: 90,
		spin: -.72,
		axialTilt: 1.71,
		swatch: "#9fd4d8",
		roughness: .48,
		metalness: .02,
		atmosphereColor: "#b7e4e8",
		atmosphereScale: 1.05,
		inPicker: true,
		distanceAu: "19.2 AU",
		diameterKm: "50,724 km",
		year: "84 years",
		day: "17.2 hours",
		moons: "28",
		summary: "An ice giant rolling on its side. A 98° tilt turns seasons into decades of day and decades of night."
	},
	{
		id: "neptune",
		name: "Neptune",
		kind: "ice-giant",
		kindLabel: "Ice giant",
		radius: .6,
		orbitRadius: 38.4,
		eccentricity: .011,
		inclination: .031,
		orbitPeriod: 112,
		spin: .78,
		axialTilt: .49,
		swatch: "#4d7fd0",
		roughness: .46,
		metalness: .02,
		atmosphereColor: "#6ea0e8",
		atmosphereScale: 1.05,
		inPicker: true,
		distanceAu: "30.1 AU",
		diameterKm: "49,244 km",
		year: "165 years",
		day: "16.1 hours",
		moons: "16",
		summary: "The farthest planet, and the windiest. Methane stains it a deep blue; a dark storm still rides its southern haze."
	},
	{
		id: "pluto",
		name: "Pluto",
		kind: "dwarf",
		kindLabel: "Dwarf planet",
		radius: .16,
		orbitRadius: 44.5,
		eccentricity: .25,
		inclination: .3,
		orbitPeriod: 142,
		spin: -.2,
		axialTilt: 2.12,
		swatch: "#cbb8a4",
		roughness: .9,
		metalness: 0,
		inPicker: true,
		distanceAu: "39.5 AU",
		diameterKm: "2,377 km",
		year: "248 years",
		day: "6.4 days",
		moons: "5",
		summary: "A heart-marked wanderer of the Kuiper belt. Its tilted, eccentric orbit still carries it inside Neptune's path."
	}
];
var BODY_BY_ID = Object.fromEntries(BODIES.map((body) => [body.id, body]));
var PICKER_BODIES = BODIES.filter((body) => body.inPicker);
var ORBITING_BODIES = BODIES.filter((body) => body.orbitRadius > 0 && !body.parentId);
var AXIS_X = new Vector3(1, 0, 0);
var scratch = new Vector3();
var sim = { elapsed: 0 };
var bodyWorld = Object.fromEntries(BODIES.map((body) => [body.id, new Vector3()]));
function orbitPosition(body, elapsed, target) {
	if (body.orbitRadius <= 0) {
		target.set(0, 0, 0);
		return;
	}
	const anomaly = elapsed / body.orbitPeriod * Math.PI * 2;
	const e = body.eccentricity;
	const radius = body.orbitRadius * (1 - e * e) / (1 + e * Math.cos(anomaly));
	target.set(Math.cos(anomaly) * radius, 0, Math.sin(anomaly) * radius);
	if (body.inclination !== 0) target.applyAxisAngle(AXIS_X, body.inclination);
}
function updateBodyWorld(elapsed) {
	for (const body of BODIES) {
		const target = bodyWorld[body.id];
		if (body.parentId) {
			const parent = bodyWorld[body.parentId];
			const anomaly = elapsed / body.orbitPeriod * Math.PI * 2;
			const e = body.eccentricity;
			const radius = body.orbitRadius * (1 - e * e) / (1 + e * Math.cos(anomaly));
			scratch.set(Math.cos(anomaly) * radius, 0, Math.sin(anomaly) * radius);
			if (body.inclination !== 0) scratch.applyAxisAngle(AXIS_X, body.inclination);
			target.copy(parent).add(scratch);
		} else orbitPosition(body, elapsed, target);
	}
}
function orbitCurve(body, segments = 160) {
	const points = [];
	for (let i = 0; i <= segments; i += 1) {
		const t = i / segments * body.orbitPeriod;
		const point = new Vector3();
		orbitPosition(body, t, point);
		points.push(point);
	}
	return points;
}
function focusDistance(body) {
	if (body.id === "sun") return 11.5;
	return (body.hasRings ? (body.ringOuter ?? 2) * body.radius : body.radius) * 5.4 + 2.15;
}
var MIN_SPEED = .25;
var useSolarStore = create()(persist((set) => ({
	paused: false,
	speed: 1,
	selectedId: null,
	hoveredId: null,
	showLabels: true,
	showTrails: true,
	setPaused: (paused) => set({ paused }),
	togglePaused: () => set((state) => ({ paused: !state.paused })),
	setSpeed: (speed) => set({ speed: Math.min(12, Math.max(MIN_SPEED, speed)) }),
	select: (selectedId) => set({ selectedId }),
	setHovered: (hoveredId) => set({ hoveredId }),
	toggleLabels: () => set((state) => ({ showLabels: !state.showLabels })),
	toggleTrails: () => set((state) => ({ showTrails: !state.showTrails }))
}), {
	name: "orrery-prefs-v1",
	partialize: (state) => ({
		speed: state.speed,
		showLabels: state.showLabels,
		showTrails: state.showTrails
	})
}));
function formatSpeed(speed) {
	return `${speed.toFixed(speed < 10 ? 2 : 1)}×`;
}
function useElapsedYears() {
	const [years, setYears] = (0, import_react.useState)(0);
	const paused = useSolarStore((state) => state.paused);
	(0, import_react.useEffect)(() => {
		const id = window.setInterval(() => {
			setYears(sim.elapsed / 12);
		}, paused ? 800 : 250);
		return () => window.clearInterval(id);
	}, [paused]);
	return years;
}
function IconSwap({ active, ActiveIcon, InactiveIcon }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "relative grid size-5 place-items-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: cn("absolute inset-0 grid place-items-center transition-[opacity,transform,filter] duration-[var(--motion-fast)] ease-[var(--ease-out)]", active ? "scale-100 opacity-100 blur-0" : "scale-25 opacity-0 blur-[4px]"),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActiveIcon, {
				className: "size-4",
				strokeWidth: 1.75
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: cn("grid place-items-center transition-[opacity,transform,filter] duration-[var(--motion-fast)] ease-[var(--ease-out)]", active ? "scale-25 opacity-0 blur-[4px]" : "scale-100 opacity-100 blur-0"),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InactiveIcon, {
				className: "size-4",
				strokeWidth: 1.75
			})
		})]
	});
}
function Stat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-1",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-2xs font-medium uppercase tracking-label text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "font-mono text-sm tabular-nums text-foreground",
			children: value
		})]
	});
}
function InfoPanel() {
	const selectedId = useSolarStore((state) => state.selectedId);
	const select = useSolarStore((state) => state.select);
	if (!selectedId) return null;
	const body = BODY_BY_ID[selectedId];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
		className: "panel-enter pointer-events-auto absolute inset-x-3 bottom-[7.5rem] z-10 max-h-[46vh] overflow-auto rounded-2xl bg-card p-4 shadow-[var(--shadow-panel)] md:inset-auto md:top-20 md:right-4 md:bottom-auto md:w-[22rem] md:max-h-[calc(100dvh-8rem)] md:rounded-xl md:p-5",
		"aria-live": "polite",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-2xs font-medium uppercase tracking-label text-muted-foreground",
						children: body.kindLabel
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-3xl font-medium tracking-display text-foreground",
						children: body.name
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					size: "icon-sm",
					className: "shrink-0",
					"aria-label": "Close planet details",
					onClick: () => select(null),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {
						className: "size-4",
						strokeWidth: 1.75
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 grid grid-cols-2 gap-x-4 gap-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Distance",
						value: body.distanceAu
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Diameter",
						value: body.diameterKm
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Year",
						value: body.year
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Day",
						value: body.day
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Moons",
						value: body.moons
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Path",
						value: body.eccentricity > .05 ? "Eccentric" : "Near-circular"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "stagger-2 mt-4 text-sm leading-normal text-muted-foreground",
				children: body.summary
			})
		]
	});
}
function BodyList({ className }) {
	const selectedId = useSolarStore((state) => state.selectedId);
	const select = useSolarStore((state) => state.select);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
		className: cn("flex gap-1", className),
		"aria-label": "Solar system",
		children: PICKER_BODIES.map((body) => {
			const active = selectedId === body.id;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => select(active ? null : body.id),
				className: cn("flex h-11 shrink-0 items-center gap-2 rounded-md px-2.5 text-left transition-[background-color,color,box-shadow] duration-[var(--motion-quick)] ease-[var(--ease-out)]", active ? "bg-muted text-foreground" : "text-muted-foreground hover:bg-muted/70 hover:text-foreground"),
				"aria-pressed": active,
				"aria-label": `Focus ${body.name}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "size-2 shrink-0 rounded-full",
					style: { backgroundColor: body.swatch },
					"aria-hidden": "true"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs font-medium",
					children: body.name
				})]
			}, body.id);
		})
	});
}
function Hud() {
	const paused = useSolarStore((state) => state.paused);
	const speed = useSolarStore((state) => state.speed);
	const showLabels = useSolarStore((state) => state.showLabels);
	const showTrails = useSolarStore((state) => state.showTrails);
	const selectedId = useSolarStore((state) => state.selectedId);
	const togglePaused = useSolarStore((state) => state.togglePaused);
	const setSpeed = useSolarStore((state) => state.setSpeed);
	const toggleLabels = useSolarStore((state) => state.toggleLabels);
	const toggleTrails = useSolarStore((state) => state.toggleTrails);
	const select = useSolarStore((state) => state.select);
	const years = useElapsedYears();
	(0, import_react.useEffect)(() => {
		const onKey = (event) => {
			const target = event.target;
			if (target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement) return;
			if (event.code === "Space") {
				event.preventDefault();
				togglePaused();
			} else if (event.code === "Escape") select(null);
			else if (event.key === "[" || event.key === "-") setSpeed(speed - .25);
			else if (event.key === "]" || event.key === "=" || event.key === "+") setSpeed(speed + .25);
			else if (event.key === "l" || event.key === "L") toggleLabels();
			else if (event.key === "t" || event.key === "T") toggleTrails();
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [
		speed,
		togglePaused,
		setSpeed,
		toggleLabels,
		toggleTrails,
		select
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "pointer-events-none absolute inset-0 z-10 text-foreground",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "pointer-events-auto absolute top-0 left-0 flex max-w-[min(100%,22rem)] flex-col gap-3 p-3 pt-[max(0.75rem,env(safe-area-inset-top))] md:p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl bg-card/95 px-4 py-3 shadow-[var(--shadow-panel)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-2xs font-medium uppercase tracking-label text-muted-foreground",
							children: "Solar model"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "font-display text-3xl font-medium tracking-display",
							children: "Orrery"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-xs text-muted-foreground",
							children: "A living model of the solar system."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-3 font-mono text-2xs tabular-nums text-muted-foreground",
							children: [
								"Elapsed ",
								years.toFixed(2),
								" Earth years",
								paused ? " · Paused" : ""
							]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "hidden rounded-xl bg-card/95 p-2 shadow-[var(--shadow-panel)] md:block",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BodyList, { className: "flex-col" })
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoPanel, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-auto absolute right-3 top-[max(0.75rem,env(safe-area-inset-top))] md:right-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					size: "icon",
					className: "bg-card/95",
					"aria-label": "Reset camera to the whole system",
					onClick: () => select(null),
					disabled: !selectedId,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Undo2, {
						className: "size-4",
						strokeWidth: 1.75
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-auto absolute inset-x-0 bottom-0 pb-[max(0.75rem,env(safe-area-inset-bottom))]",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-3xl flex-col gap-2 px-3 md:px-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "md:hidden overflow-x-auto rounded-xl bg-card/95 p-1 shadow-[var(--shadow-panel)]",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BodyList, { className: "w-max" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col gap-2 rounded-xl bg-card/95 p-2 shadow-[var(--shadow-panel)] sm:flex-row sm:items-center sm:gap-3 sm:px-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										variant: "ghost",
										size: "icon",
										"aria-label": paused ? "Resume simulation" : "Pause simulation",
										onClick: togglePaused,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconSwap, {
											active: !paused,
											ActiveIcon: Pause,
											InactiveIcon: Play
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										variant: "ghost",
										size: "icon",
										"aria-label": showLabels ? "Hide labels" : "Show labels",
										onClick: toggleLabels,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconSwap, {
											active: showLabels,
											ActiveIcon: Captions,
											InactiveIcon: CaptionsOff
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										variant: "ghost",
										size: "icon",
										"aria-label": showTrails ? "Hide orbital trails" : "Show orbital trails",
										onClick: toggleTrails,
										className: showTrails ? "text-foreground" : "text-muted-foreground",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Orbit, {
											className: "size-4",
											strokeWidth: 1.75
										})
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex min-w-0 flex-1 items-center gap-3 px-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										htmlFor: "sim-speed",
										className: "shrink-0 text-2xs font-medium uppercase tracking-label text-muted-foreground",
										children: "Speed"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
										id: "sim-speed",
										min: MIN_SPEED,
										max: 12,
										step: .25,
										value: [speed],
										onValueChange: (value) => {
											const next = value[0];
											if (typeof next === "number") setSpeed(next);
										},
										"aria-label": "Simulation speed"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "w-12 shrink-0 text-right font-mono text-xs tabular-nums text-foreground",
										children: formatSpeed(speed)
									})
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "hidden px-1 pb-1 text-center text-2xs text-muted-foreground md:block",
							children: "Drag to orbit · Scroll to zoom · Click a world to inspect · Space pauses"
						})
					]
				})
			})
		]
	});
}
var textureCache = /* @__PURE__ */ new Map();
function hash(x, y) {
	const s = Math.sin(x * 127.1 + y * 311.7) * 43758.5453;
	return s - Math.floor(s);
}
function lerp(a, b, t) {
	return a + (b - a) * t;
}
function smoothNoise(x, y) {
	const ix = Math.floor(x);
	const iy = Math.floor(y);
	const fx = x - ix;
	const fy = y - iy;
	const u = fx * fx * (3 - 2 * fx);
	const v = fy * fy * (3 - 2 * fy);
	return lerp(lerp(hash(ix, iy), hash(ix + 1, iy), u), lerp(hash(ix, iy + 1), hash(ix + 1, iy + 1), u), v);
}
function fbm(x, y, octaves = 5) {
	let value = 0;
	let amp = .5;
	for (let i = 0; i < octaves; i += 1) {
		value += amp * smoothNoise(x, y);
		x *= 2;
		y *= 2;
		amp *= .5;
	}
	return value;
}
function canvasTexture(width, height, paint) {
	const canvas = document.createElement("canvas");
	canvas.width = width;
	canvas.height = height;
	const ctx = canvas.getContext("2d", { alpha: true });
	if (!ctx) throw new Error("Canvas 2D unavailable");
	paint(ctx, width, height);
	const texture = new CanvasTexture(canvas);
	texture.colorSpace = SRGBColorSpace;
	texture.anisotropy = 4;
	texture.wrapS = RepeatWrapping;
	texture.wrapT = ClampToEdgeWrapping;
	texture.needsUpdate = true;
	return texture;
}
function fillNoise(ctx, w, h, color, scale = 6) {
	const image = ctx.createImageData(w, h);
	const data = image.data;
	for (let y = 0; y < h; y += 1) for (let x = 0; x < w; x += 1) {
		const u = x / w;
		const v = y / h;
		const [r, g, b] = color(fbm(u * scale, v * scale * .5), u, v);
		const i = (y * w + x) * 4;
		data[i] = r;
		data[i + 1] = g;
		data[i + 2] = b;
		data[i + 3] = 255;
	}
	ctx.putImageData(image, 0, 0);
}
function paintSun(ctx, w, h) {
	fillNoise(ctx, w, h, (n) => {
		const t = n * n;
		return [
			255,
			lerp(170, 230, t),
			lerp(70, 140, t)
		];
	}, 14);
}
function paintMercury(ctx, w, h) {
	fillNoise(ctx, w, h, (n, _u, v) => {
		const polar = Math.abs(v - .5);
		const shade = lerp(78, 160, n) - polar * 18;
		return [
			shade,
			shade * .94,
			shade * .86
		];
	}, 18);
	ctx.globalCompositeOperation = "multiply";
	for (let i = 0; i < 90; i += 1) {
		const x = hash(i, 2) * w;
		const y = hash(i, 9) * h;
		const r = 2 + hash(i, 4) * 9;
		ctx.fillStyle = `rgba(20,18,16,${.12 + hash(i, 6) * .28})`;
		ctx.beginPath();
		ctx.ellipse(x, y, r, r * .7, 0, 0, Math.PI * 2);
		ctx.fill();
	}
	ctx.globalCompositeOperation = "source-over";
}
function paintVenus(ctx, w, h) {
	fillNoise(ctx, w, h, (n, _u, v) => {
		const swirl = Math.sin((v + n * .2) * Math.PI * 8);
		const t = .55 + n * .3 + swirl * .08;
		return [
			lerp(190, 236, t),
			lerp(150, 210, t),
			lerp(90, 140, t)
		];
	}, 9);
}
function paintEarth(ctx, w, h) {
	const image = ctx.createImageData(w, h);
	const data = image.data;
	for (let y = 0; y < h; y += 1) for (let x = 0; x < w; x += 1) {
		const u = x / w;
		const v = y / h;
		const n = fbm(u * 7, v * 4, 6);
		const warp = fbm(u * 3 + 8, v * 3, 3);
		const land = n > .52 - Math.sin(v * Math.PI) * .04 + (warp - .5) * .12;
		const ice = v < .08 + n * .04 || v > .92 - n * .04;
		let r;
		let g;
		let b;
		if (ice) {
			r = 232;
			g = 240;
			b = 248;
		} else if (land) {
			const arid = fbm(u * 10, v * 8);
			r = lerp(42, 150, arid);
			g = lerp(92, 140, arid);
			b = lerp(46, 70, arid);
		} else {
			const deep = fbm(u * 4, v * 4);
			r = lerp(8, 30, deep);
			g = lerp(40, 90, deep);
			b = lerp(90, 150, deep);
		}
		const cloud = fbm(u * 11 + 3, v * 6, 4);
		if (cloud > .62) {
			const a = (cloud - .62) * 1.6;
			r = lerp(r, 245, a);
			g = lerp(g, 248, a);
			b = lerp(b, 252, a);
		}
		const i = (y * w + x) * 4;
		data[i] = r;
		data[i + 1] = g;
		data[i + 2] = b;
		data[i + 3] = 255;
	}
	ctx.putImageData(image, 0, 0);
}
function paintMoon(ctx, w, h) {
	fillNoise(ctx, w, h, (n) => {
		const s = lerp(88, 196, n);
		return [
			s,
			s * .98,
			s * .92
		];
	}, 16);
	ctx.globalCompositeOperation = "multiply";
	for (let i = 0; i < 70; i += 1) {
		const x = hash(i, 1) * w;
		const y = hash(i, 4) * h;
		const r = 2 + hash(i, 8) * 12;
		ctx.fillStyle = `rgba(30,28,26,${.1 + hash(i, 5) * .25})`;
		ctx.beginPath();
		ctx.ellipse(x, y, r, r * .72, 0, 0, Math.PI * 2);
		ctx.fill();
	}
	ctx.globalCompositeOperation = "source-over";
}
function paintMars(ctx, w, h) {
	fillNoise(ctx, w, h, (n, _u, v) => {
		if (v < .07 + n * .03 || v > .93 - n * .03) return [
			236,
			238,
			242
		];
		const rust = lerp(.35, 1, n);
		return [
			lerp(90, 196, rust),
			lerp(42, 96, rust),
			lerp(28, 58, rust)
		];
	}, 11);
}
function paintBands(ctx, w, h, palette, turbulence = 1, spot) {
	const image = ctx.createImageData(w, h);
	const data = image.data;
	for (let y = 0; y < h; y += 1) for (let x = 0; x < w; x += 1) {
		const u = x / w;
		const v = y / h;
		const n = fbm(u * 8, v * 14, 4);
		const band = (v * palette.length + n * .35 * turbulence + Math.sin(u * Math.PI * 2 + n) * .08) % palette.length;
		const i0 = Math.floor(band);
		const i1 = (i0 + 1) % palette.length;
		const t = band - i0;
		const c0 = palette[i0] ?? palette[0];
		const c1 = palette[i1] ?? palette[0];
		let r = lerp(c0[0], c1[0], t);
		let g = lerp(c0[1], c1[1], t);
		let b = lerp(c0[2], c1[2], t);
		if (spot) {
			const du = (u - spot.u) / spot.rw;
			const dv = (v - spot.v) / spot.rh;
			if (du * du + dv * dv < 1) {
				const k = 1 - (du * du + dv * dv);
				r = lerp(r, spot.color[0], k);
				g = lerp(g, spot.color[1], k);
				b = lerp(b, spot.color[2], k);
			}
		}
		const i = (y * w + x) * 4;
		data[i] = r;
		data[i + 1] = g;
		data[i + 2] = b;
		data[i + 3] = 255;
	}
	ctx.putImageData(image, 0, 0);
}
function paintJupiter(ctx, w, h) {
	paintBands(ctx, w, h, [
		[
			214,
			176,
			128
		],
		[
			186,
			140,
			96
		],
		[
			232,
			208,
			168
		],
		[
			168,
			122,
			86
		],
		[
			206,
			166,
			118
		],
		[
			150,
			108,
			78
		]
	], 1.2, {
		u: .62,
		v: .62,
		rw: .08,
		rh: .055,
		color: [
			176,
			78,
			48
		]
	});
}
function paintSaturn(ctx, w, h) {
	paintBands(ctx, w, h, [
		[
			232,
			214,
			170
		],
		[
			214,
			190,
			140
		],
		[
			240,
			226,
			190
		],
		[
			198,
			176,
			128
		],
		[
			226,
			208,
			164
		]
	], .7);
}
function paintUranus(ctx, w, h) {
	fillNoise(ctx, w, h, (n, _u, v) => {
		const polar = Math.abs(v - .5);
		const t = n * .25 + polar * .15;
		return [
			lerp(140, 186, t),
			lerp(196, 226, t),
			lerp(200, 228, t)
		];
	}, 5);
}
function paintNeptune(ctx, w, h) {
	paintBands(ctx, w, h, [
		[
			46,
			86,
			176
		],
		[
			62,
			110,
			196
		],
		[
			38,
			72,
			150
		],
		[
			86,
			132,
			210
		],
		[
			40,
			78,
			160
		]
	], .9, {
		u: .7,
		v: .58,
		rw: .07,
		rh: .05,
		color: [
			18,
			36,
			80
		]
	});
}
function paintPluto(ctx, w, h) {
	fillNoise(ctx, w, h, (n, u, v) => {
		if (Math.hypot((u - .42) / .16, (v - .48) / .12) < 1) return [
			232,
			214,
			206
		];
		const t = n;
		return [
			lerp(96, 186, t),
			lerp(78, 150, t),
			lerp(64, 122, t)
		];
	}, 8);
}
var painters = {
	sun: paintSun,
	mercury: paintMercury,
	venus: paintVenus,
	earth: paintEarth,
	moon: paintMoon,
	mars: paintMars,
	jupiter: paintJupiter,
	saturn: paintSaturn,
	uranus: paintUranus,
	neptune: paintNeptune,
	pluto: paintPluto
};
function getBodyTexture(id) {
	const cached = textureCache.get(id);
	if (cached) return cached;
	const paint = painters[id] ?? paintMercury;
	const large = id === "earth" || id === "jupiter" || id === "sun";
	const texture = canvasTexture(large ? 1024 : 512, large ? 512 : 256, paint);
	textureCache.set(id, texture);
	return texture;
}
function getGlowTexture() {
	const cached = textureCache.get("glow");
	if (cached) return cached;
	const texture = canvasTexture(256, 256, (ctx, w, h) => {
		const gradient = ctx.createRadialGradient(w / 2, h / 2, 0, w / 2, h / 2, w / 2);
		gradient.addColorStop(0, "rgba(255, 244, 214, 0.95)");
		gradient.addColorStop(.18, "rgba(255, 196, 110, 0.45)");
		gradient.addColorStop(.42, "rgba(255, 140, 48, 0.12)");
		gradient.addColorStop(1, "rgba(255, 120, 20, 0)");
		ctx.fillStyle = gradient;
		ctx.fillRect(0, 0, w, h);
	});
	texture.wrapS = ClampToEdgeWrapping;
	textureCache.set("glow", texture);
	return texture;
}
function getRingTexture() {
	const cached = textureCache.get("saturn-rings");
	if (cached) return cached;
	const texture = canvasTexture(8, 512, (ctx, w, h) => {
		const image = ctx.createImageData(w, h);
		const data = image.data;
		for (let y = 0; y < h; y += 1) {
			const v = y / h;
			const cassini = v > .46 && v < .52;
			const gap2 = v > .78 && v < .8;
			const band = .35 + Math.sin(v * Math.PI * 48) * .18 + fbm(2, v * 20, 3) * .25;
			const alpha = cassini || gap2 ? 0 : Math.max(0, Math.min(1, band));
			const shade = 180 + Math.sin(v * 30) * 30;
			for (let x = 0; x < w; x += 1) {
				const i = (y * w + x) * 4;
				data[i] = shade;
				data[i + 1] = shade * .92;
				data[i + 2] = shade * .78;
				data[i + 3] = alpha * 220;
			}
		}
		ctx.putImageData(image, 0, 0);
	});
	texture.wrapS = RepeatWrapping;
	texture.wrapT = ClampToEdgeWrapping;
	textureCache.set("saturn-rings", texture);
	return texture;
}
var DEFAULT_OFFSET = new Vector3(22, 14, 32);
var tmpTarget = new Vector3();
var tmpCam = new Vector3();
var tmpOffset = new Vector3();
function CameraRig() {
	const controlsRef = (0, import_react.useRef)(null);
	const offsetRef = (0, import_react.useRef)(DEFAULT_OFFSET.clone());
	const lastTarget = (0, import_react.useRef)(new Vector3());
	const anim = (0, import_react.useRef)(1);
	const selectedId = useSolarStore((state) => state.selectedId);
	const { camera } = useThree();
	const size = useThree((state) => state.size);
	(0, import_react.useEffect)(() => {
		anim.current = 1;
		const body = selectedId ? BODY_BY_ID[selectedId] : null;
		const dist = body ? focusDistance(body) : DEFAULT_OFFSET.length();
		const current = offsetRef.current.length() > .01 ? offsetRef.current.clone().normalize() : DEFAULT_OFFSET.clone().normalize();
		offsetRef.current.copy(current).multiplyScalar(dist);
	}, [selectedId]);
	useFrame((_, delta) => {
		const controls = controlsRef.current;
		if (!controls) return;
		const dt = Math.min(delta, .1);
		const body = selectedId ? BODY_BY_ID[selectedId] : null;
		if (body) tmpTarget.copy(bodyWorld[body.id]);
		else tmpTarget.set(0, 0, 0);
		if (anim.current > 0) {
			const dist = body ? focusDistance(body) : DEFAULT_OFFSET.length();
			tmpOffset.copy(offsetRef.current).normalize().multiplyScalar(dist);
			tmpCam.copy(tmpTarget).add(tmpOffset);
			const k = 1 - Math.exp(-3.1 * dt);
			camera.position.lerp(tmpCam, k);
			controls.target.lerp(tmpTarget, k);
			offsetRef.current.copy(camera.position).sub(controls.target);
			anim.current = Math.max(0, anim.current - dt * .85);
			if (camera.position.distanceTo(tmpCam) < .08) anim.current = 0;
		} else {
			tmpOffset.copy(tmpTarget).sub(lastTarget.current);
			camera.position.add(tmpOffset);
			controls.target.copy(tmpTarget);
			offsetRef.current.copy(camera.position).sub(controls.target);
		}
		lastTarget.current.copy(controls.target);
		controls.update();
	});
	const isMobile = size.width < 640;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrbitControls, {
		ref: controlsRef,
		makeDefault: true,
		enablePan: false,
		enableDamping: true,
		dampingFactor: .08,
		minDistance: selectedId === "sun" ? 6 : 1.6,
		maxDistance: 96,
		minPolarAngle: .18,
		maxPolarAngle: Math.PI - .18,
		rotateSpeed: isMobile ? .7 : .85,
		zoomSpeed: .85
	});
}
var dummy = new Object3D();
function hash01(n) {
	const s = Math.sin(n * 127.1) * 43758.5453;
	return s - Math.floor(s);
}
function SimClock() {
	const paused = useSolarStore((state) => state.paused);
	const speed = useSolarStore((state) => state.speed);
	useFrame((_, delta) => {
		const dt = Math.min(delta, .1);
		if (!paused) sim.elapsed += dt * speed;
		updateBodyWorld(sim.elapsed);
	}, -10);
	return null;
}
function BodyLabel({ body, offset }) {
	const visible = useSolarStore((state) => state.showLabels);
	const selected = useSolarStore((state) => state.selectedId === body.id);
	const hovered = useSolarStore((state) => state.hoveredId === body.id);
	if (!visible) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Html, {
		position: [
			0,
			offset,
			0
		],
		center: true,
		sprite: true,
		distanceFactor: 28,
		style: {
			pointerEvents: "none",
			userSelect: "none"
		},
		zIndexRange: [0, 0],
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: `whitespace-nowrap font-sans text-2xs font-medium uppercase tracking-label ${selected || hovered ? "text-foreground" : "text-foreground/70"}`,
			children: body.name
		})
	});
}
function OrbitTrail({ body }) {
	const show = useSolarStore((state) => state.showTrails);
	const points = (0, import_react.useMemo)(() => orbitCurve(body), [body]);
	if (!show) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
		points,
		color: body.swatch,
		transparent: true,
		opacity: .28,
		lineWidth: 1,
		depthWrite: false
	});
}
function PlanetaryBody({ body }) {
	const groupRef = (0, import_react.useRef)(null);
	const spinRef = (0, import_react.useRef)(null);
	const selectedId = useSolarStore((state) => state.selectedId);
	const select = useSolarStore((state) => state.select);
	const setHovered = useSolarStore((state) => state.setHovered);
	const map = (0, import_react.useMemo)(() => getBodyTexture(body.id), [body.id]);
	const ringMap = (0, import_react.useMemo)(() => body.hasRings ? getRingTexture() : null, [body.hasRings]);
	const selected = selectedId === body.id;
	useFrame(() => {
		const group = groupRef.current;
		if (!group) return;
		if (body.parentId) {
			const parent = bodyWorld[body.parentId];
			group.position.copy(bodyWorld[body.id]).sub(parent);
		} else group.position.copy(bodyWorld[body.id]);
		if (spinRef.current) spinRef.current.rotation.y = sim.elapsed * body.spin;
	}, -5);
	const onOver = (event) => {
		event.stopPropagation();
		setHovered(body.id);
		document.body.style.cursor = "pointer";
	};
	const onOut = () => {
		setHovered(null);
		document.body.style.cursor = "";
	};
	const children = BODIES.filter((child) => child.parentId === body.id);
	const ringExtent = body.hasRings ? body.ringOuter ?? 2.2 : 1;
	const labelOffset = body.radius * ringExtent + .38;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", {
		ref: groupRef,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("group", {
				rotation: [
					0,
					0,
					body.axialTilt
				],
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", {
					ref: spinRef,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
							scale: body.radius,
							onClick: (event) => {
								event.stopPropagation();
								select(body.id);
							},
							onPointerOver: onOver,
							onPointerOut: onOut,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
								1,
								48,
								32
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
								map,
								roughness: body.roughness,
								metalness: body.metalness,
								emissive: body.emissive ?? "#000000",
								emissiveIntensity: body.emissiveIntensity ?? 0,
								emissiveMap: body.emissive ? map : void 0
							})]
						}),
						body.atmosphereColor ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
							scale: body.radius * (body.atmosphereScale ?? 1.06),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
								1,
								32,
								24
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshBasicMaterial", {
								color: body.atmosphereColor,
								transparent: true,
								opacity: .14,
								side: 1,
								depthWrite: false
							})]
						}) : null,
						body.hasRings && ringMap ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
							rotation: [
								Math.PI / 2,
								0,
								0
							],
							scale: body.radius,
							onClick: (event) => {
								event.stopPropagation();
								select(body.id);
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ringGeometry", { args: [
								body.ringInner ?? 1.3,
								body.ringOuter ?? 2.3,
								96
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
								map: ringMap,
								transparent: true,
								side: 2,
								depthWrite: false,
								roughness: .6,
								metalness: .05
							})]
						}) : null
					]
				})
			}),
			selected ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				rotation: [
					Math.PI / 2,
					0,
					0
				],
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ringGeometry", { args: [
					labelOffset * .72,
					labelOffset * .76,
					64
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshBasicMaterial", {
					color: "#e8eaef",
					transparent: true,
					opacity: .7,
					side: 2
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BodyLabel, {
				body,
				offset: labelOffset
			}),
			children.map((child) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlanetaryBody, { body: child }, child.id))
		]
	});
}
function Sun() {
	const body = BODY_BY_ID.sun;
	const glow = (0, import_react.useMemo)(() => getGlowTexture(), []);
	const map = (0, import_react.useMemo)(() => getBodyTexture("sun"), []);
	const spinRef = (0, import_react.useRef)(null);
	const select = useSolarStore((state) => state.select);
	const setHovered = useSolarStore((state) => state.setHovered);
	useFrame(() => {
		if (spinRef.current) spinRef.current.rotation.y = sim.elapsed * body.spin;
	}, -5);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pointLight", {
			color: "#fff1c8",
			intensity: 18,
			distance: 140,
			decay: 1.55
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("group", {
			ref: spinRef,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				scale: body.radius,
				onClick: (event) => {
					event.stopPropagation();
					select("sun");
				},
				onPointerOver: (event) => {
					event.stopPropagation();
					setHovered("sun");
					document.body.style.cursor = "pointer";
				},
				onPointerOut: () => {
					setHovered(null);
					document.body.style.cursor = "";
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
					1,
					48,
					32
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
					map,
					emissive: "#ffd59a",
					emissiveMap: map,
					emissiveIntensity: 1.55,
					roughness: 1,
					metalness: 0,
					toneMapped: false
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sprite", {
			scale: [
				14,
				14,
				1
			],
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("spriteMaterial", {
				map: glow,
				blending: 2,
				depthWrite: false,
				transparent: true,
				opacity: .9
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sprite", {
			scale: [
				26,
				26,
				1
			],
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("spriteMaterial", {
				map: glow,
				blending: 2,
				depthWrite: false,
				transparent: true,
				opacity: .35
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BodyLabel, {
			body,
			offset: body.radius + .55
		})
	] });
}
function AsteroidBelt() {
	const meshRef = (0, import_react.useRef)(null);
	const paused = useSolarStore((state) => state.paused);
	const speed = useSolarStore((state) => state.speed);
	const count = 360;
	(0, import_react.useLayoutEffect)(() => {
		const mesh = meshRef.current;
		if (!mesh) return;
		for (let i = 0; i < count; i += 1) {
			const a = i / count * Math.PI * 2 + hash01(i) * .35;
			const r = 15.5 + hash01(i + 11) * 2.4;
			dummy.position.set(Math.cos(a) * r, (hash01(i + 3) - .5) * .42, Math.sin(a) * r);
			dummy.rotation.set(hash01(i) * 6, hash01(i + 1) * 6, hash01(i + 2) * 6);
			dummy.scale.setScalar(.018 + hash01(i + 5) * .05);
			dummy.updateMatrix();
			mesh.setMatrixAt(i, dummy.matrix);
		}
		mesh.instanceMatrix.needsUpdate = true;
		mesh.computeBoundingSphere();
	}, [count]);
	useFrame((_, delta) => {
		if (!meshRef.current || paused) return;
		meshRef.current.rotation.y += Math.min(delta, .1) * .01 * speed;
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("instancedMesh", {
		ref: meshRef,
		args: [
			void 0,
			void 0,
			count
		],
		frustumCulled: false,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("icosahedronGeometry", { args: [1, 0] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
			color: "#6d675e",
			roughness: .96,
			metalness: .04
		})]
	});
}
function Scene() {
	const planets = BODIES.filter((body) => !body.parentId && body.id !== "sun");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("color", {
			attach: "background",
			args: ["#050508"]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("hemisphereLight", { args: [
			"#151a28",
			"#09080a",
			.42
		] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ambientLight", { intensity: .035 }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stars, {
			radius: 110,
			depth: 48,
			count: 2600,
			factor: 2.5,
			saturation: .05,
			fade: true,
			speed: .28
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SimClock, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, {}),
		ORBITING_BODIES.map((body) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrbitTrail, { body }, `trail-${body.id}`)),
		planets.map((body) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlanetaryBody, { body }, body.id)),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AsteroidBelt, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CameraRig, {})
	] });
}
function SolarApp() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative h-dvh w-full overflow-hidden bg-background text-foreground",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Canvas, {
			className: "touch-none",
			dpr: [1, 1.75],
			camera: {
				position: [
					22,
					14,
					32
				],
				fov: 42,
				near: .1,
				far: 250
			},
			gl: {
				antialias: true,
				alpha: false,
				powerPreference: "high-performance",
				toneMapping: 4,
				toneMappingExposure: 1.02
			},
			onCreated: ({ gl }) => {
				gl.setClearColor("#050508", 1);
			},
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scene, {})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hud, {})]
	});
}
//#endregion
export { SolarApp };
