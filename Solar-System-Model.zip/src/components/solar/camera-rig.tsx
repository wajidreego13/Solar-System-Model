import { OrbitControls } from "@react-three/drei";
import { useFrame, useThree } from "@react-three/fiber";
import { useEffect, useRef } from "react";
import * as THREE from "three";
import type { OrbitControls as OrbitControlsImpl } from "three-stdlib";
import { BODY_BY_ID } from "@/lib/solar/bodies";
import { bodyWorld, focusDistance } from "@/lib/solar/sim";
import { useSolarStore } from "@/lib/solar/store";

const DEFAULT_OFFSET = new THREE.Vector3(22, 14, 32);
const tmpTarget = new THREE.Vector3();
const tmpCam = new THREE.Vector3();
const tmpOffset = new THREE.Vector3();

export function CameraRig() {
  const controlsRef = useRef<OrbitControlsImpl>(null);
  const offsetRef = useRef(DEFAULT_OFFSET.clone());
  const lastTarget = useRef(new THREE.Vector3());
  const anim = useRef(1);
  const selectedId = useSolarStore((state) => state.selectedId);
  const { camera } = useThree();
  const size = useThree((state) => state.size);

  useEffect(() => {
    anim.current = 1;
    const body = selectedId ? BODY_BY_ID[selectedId] : null;
    const dist = body ? focusDistance(body) : DEFAULT_OFFSET.length();
    const current = offsetRef.current.length() > 0.01 ? offsetRef.current.clone().normalize() : DEFAULT_OFFSET.clone().normalize();
    offsetRef.current.copy(current).multiplyScalar(dist);
  }, [selectedId]);

  useFrame((_, delta) => {
    const controls = controlsRef.current;
    if (!controls) return;
    const dt = Math.min(delta, 0.1);
    const body = selectedId ? BODY_BY_ID[selectedId] : null;
    if (body) tmpTarget.copy(bodyWorld[body.id]);
    else tmpTarget.set(0, 0, 0);

    if (anim.current > 0) {
      const dist = body ? focusDistance(body) : DEFAULT_OFFSET.length();
      tmpOffset.copy(offsetRef.current).normalize().multiplyScalar(dist);
      tmpCam.copy(tmpTarget).add(tmpOffset);
      const k = 1 - Math.exp(-3.1 * dt);
      camera.position.lerp(tmpCam, k);
      controls.target.lerp(tmpTarget, k);
      offsetRef.current.copy(camera.position).sub(controls.target);
      anim.current = Math.max(0, anim.current - dt * 0.85);
      if (camera.position.distanceTo(tmpCam) < 0.08) anim.current = 0;
    } else {
      tmpOffset.copy(tmpTarget).sub(lastTarget.current);
      camera.position.add(tmpOffset);
      controls.target.copy(tmpTarget);
      offsetRef.current.copy(camera.position).sub(controls.target);
    }

    lastTarget.current.copy(controls.target);
    controls.update();
  });

  const isMobile = size.width < 640;

  return (
    <OrbitControls
      ref={controlsRef}
      makeDefault
      enablePan={false}
      enableDamping
      dampingFactor={0.08}
      minDistance={selectedId === "sun" ? 6 : 1.6}
      maxDistance={96}
      minPolarAngle={0.18}
      maxPolarAngle={Math.PI - 0.18}
      rotateSpeed={isMobile ? 0.7 : 0.85}
      zoomSpeed={0.85}
    />
  );
}
