import { Line } from "@react-three/drei";
import { useFrame, useThree } from "@react-three/fiber";
import { useLayoutEffect, useMemo, useRef } from "react";
import * as THREE from "three";
import { BODIES, ORBITING_BODIES, BODY_BY_ID, type BodyDef } from "@/lib/solar/bodies";
import { bodyWorld, orbitCurve, sim, updateBodyWorld } from "@/lib/solar/sim";
import { useSolarStore } from "@/lib/solar/store";
import { getBodyTexture, getGlowTexture, getRingTexture } from "@/lib/solar/textures";
import { CameraRig } from "./camera-rig";

const dummy = new THREE.Object3D();

function hash01(n: number) {
  const s = Math.sin(n * 127.1) * 43758.5453;
  return s - Math.floor(s);
}

function SimClock() {
  const paused = useSolarStore((state) => state.paused);
  const speed = useSolarStore((state) => state.speed);
  const { camera, size } = useThree();

  useFrame((_, delta) => {
    const dt = Math.min(delta, 0.1);
    if (!paused) sim.elapsed += dt * speed;
    updateBodyWorld(sim.elapsed);
    sim.camera = camera;
    sim.width = size.width;
    sim.height = size.height;
  }, -10);

  return null;
}

function OrbitTrail({ body }: { body: BodyDef }) {
  const show = useSolarStore((state) => state.showTrails);
  const points = useMemo(() => orbitCurve(body), [body]);
  if (!show) return null;
  return (
    <Line
      points={points}
      color={body.swatch}
      transparent
      opacity={0.28}
      lineWidth={1}
      depthWrite={false}
    />
  );
}

function PlanetaryBody({ body }: { body: BodyDef }) {
  const groupRef = useRef<THREE.Group>(null);
  const spinRef = useRef<THREE.Group>(null);
  const selectedId = useSolarStore((state) => state.selectedId);
  const select = useSolarStore((state) => state.select);
  const setHovered = useSolarStore((state) => state.setHovered);
  const map = useMemo(() => getBodyTexture(body.id), [body.id]);
  const ringMap = useMemo(() => (body.hasRings ? getRingTexture() : null), [body.hasRings]);
  const selected = selectedId === body.id;

  useFrame(() => {
    const group = groupRef.current;
    if (!group) return;
    if (body.parentId) {
      const parent = bodyWorld[body.parentId];
      group.position.copy(bodyWorld[body.id]).sub(parent);
    } else {
      group.position.copy(bodyWorld[body.id]);
    }
    if (spinRef.current) spinRef.current.rotation.y = sim.elapsed * body.spin;
  }, -5);

  const onOver = (event: { stopPropagation: () => void }) => {
    event.stopPropagation();
    setHovered(body.id);
    document.body.style.cursor = "pointer";
  };
  const onOut = () => {
    setHovered(null);
    document.body.style.cursor = "";
  };

  const children = BODIES.filter((child) => child.parentId === body.id);
  const ringExtent = body.hasRings ? (body.ringOuter ?? 2.2) : 1;
  const marker = body.radius * ringExtent + 0.28;

  return (
    <group ref={groupRef}>
      <group rotation={[0, 0, body.axialTilt]}>
        <group ref={spinRef}>
          <mesh
            scale={body.radius}
            onClick={(event) => {
              event.stopPropagation();
              select(body.id);
            }}
            onPointerOver={onOver}
            onPointerOut={onOut}
          >
            <sphereGeometry args={[1, 48, 32]} />
            <meshStandardMaterial
              map={map}
              roughness={body.roughness}
              metalness={body.metalness}
              emissive={body.emissive ?? "#000000"}
              emissiveIntensity={body.emissiveIntensity ?? 0}
              emissiveMap={body.emissive ? map : undefined}
            />
          </mesh>
          {body.atmosphereColor ? (
            <mesh scale={body.radius * (body.atmosphereScale ?? 1.06)}>
              <sphereGeometry args={[1, 32, 24]} />
              <meshBasicMaterial
                color={body.atmosphereColor}
                transparent
                opacity={0.14}
                side={THREE.BackSide}
                depthWrite={false}
              />
            </mesh>
          ) : null}
          {body.hasRings && ringMap ? (
            <mesh
              rotation={[Math.PI / 2, 0, 0]}
              scale={body.radius}
              onClick={(event) => {
                event.stopPropagation();
                select(body.id);
              }}
            >
              <ringGeometry args={[body.ringInner ?? 1.3, body.ringOuter ?? 2.3, 96]} />
              <meshStandardMaterial
                map={ringMap}
                transparent
                side={THREE.DoubleSide}
                depthWrite={false}
                roughness={0.6}
                metalness={0.05}
              />
            </mesh>
          ) : null}
        </group>
      </group>
      {selected ? (
        <mesh rotation={[Math.PI / 2, 0, 0]}>
          <ringGeometry args={[marker * 0.85, marker * 0.92, 64]} />
          <meshBasicMaterial color="#e8eaef" transparent opacity={0.7} side={THREE.DoubleSide} />
        </mesh>
      ) : null}
      {children.map((child) => (
        <PlanetaryBody key={child.id} body={child} />
      ))}
    </group>
  );
}

function Sun() {
  const body = BODY_BY_ID.sun;
  const glow = useMemo(() => getGlowTexture(), []);
  const map = useMemo(() => getBodyTexture("sun"), []);
  const spinRef = useRef<THREE.Group>(null);
  const select = useSolarStore((state) => state.select);
  const setHovered = useSolarStore((state) => state.setHovered);
  const selected = useSolarStore((state) => state.selectedId === "sun");

  useFrame(() => {
    if (spinRef.current) spinRef.current.rotation.y = sim.elapsed * body.spin;
  }, -5);

  return (
    <group>
      <pointLight color="#fff1c8" intensity={18} distance={140} decay={1.55} />
      <group ref={spinRef}>
        <mesh
          scale={body.radius}
          onClick={(event) => {
            event.stopPropagation();
            select("sun");
          }}
          onPointerOver={(event) => {
            event.stopPropagation();
            setHovered("sun");
            document.body.style.cursor = "pointer";
          }}
          onPointerOut={() => {
            setHovered(null);
            document.body.style.cursor = "";
          }}
        >
          <sphereGeometry args={[1, 48, 32]} />
          <meshStandardMaterial
            map={map}
            emissive="#ffd59a"
            emissiveMap={map}
            emissiveIntensity={1.55}
            roughness={1}
            metalness={0}
            toneMapped={false}
          />
        </mesh>
      </group>
      <sprite scale={[14, 14, 1]}>
        <spriteMaterial
          map={glow}
          blending={THREE.AdditiveBlending}
          depthWrite={false}
          transparent
          opacity={0.9}
        />
      </sprite>
      <sprite scale={[26, 26, 1]}>
        <spriteMaterial
          map={glow}
          blending={THREE.AdditiveBlending}
          depthWrite={false}
          transparent
          opacity={0.35}
        />
      </sprite>
      {selected ? (
        <mesh rotation={[Math.PI / 2, 0, 0]}>
          <ringGeometry args={[body.radius * 1.18, body.radius * 1.24, 64]} />
          <meshBasicMaterial color="#e8eaef" transparent opacity={0.55} side={THREE.DoubleSide} />
        </mesh>
      ) : null}
    </group>
  );
}

function Starfield() {
  const positions = useMemo(() => {
    const count = 2200;
    const arr = new Float32Array(count * 3);
    for (let i = 0; i < count; i += 1) {
      const r = 70 + hash01(i) * 90;
      const theta = hash01(i + 19) * Math.PI * 2;
      const phi = Math.acos(2 * hash01(i + 41) - 1);
      arr[i * 3] = r * Math.sin(phi) * Math.cos(theta);
      arr[i * 3 + 1] = r * Math.sin(phi) * Math.sin(theta);
      arr[i * 3 + 2] = r * Math.cos(phi);
    }
    return arr;
  }, []);

  return (
    <points>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" args={[positions, 3]} />
      </bufferGeometry>
      <pointsMaterial
        size={0.28}
        color="#d7dce6"
        sizeAttenuation
        transparent
        opacity={0.85}
        depthWrite={false}
      />
    </points>
  );
}

function AsteroidBelt() {
  const meshRef = useRef<THREE.InstancedMesh>(null);
  const paused = useSolarStore((state) => state.paused);
  const speed = useSolarStore((state) => state.speed);
  const count = 360;

  useLayoutEffect(() => {
    const mesh = meshRef.current;
    if (!mesh) return;
    for (let i = 0; i < count; i += 1) {
      const a = (i / count) * Math.PI * 2 + hash01(i) * 0.35;
      const r = 15.5 + hash01(i + 11) * 2.4;
      dummy.position.set(Math.cos(a) * r, (hash01(i + 3) - 0.5) * 0.42, Math.sin(a) * r);
      dummy.rotation.set(hash01(i) * 6, hash01(i + 1) * 6, hash01(i + 2) * 6);
      dummy.scale.setScalar(0.018 + hash01(i + 5) * 0.05);
      dummy.updateMatrix();
      mesh.setMatrixAt(i, dummy.matrix);
    }
    mesh.instanceMatrix.needsUpdate = true;
    mesh.computeBoundingSphere();
  }, [count]);

  useFrame((_, delta) => {
    if (!meshRef.current || paused) return;
    meshRef.current.rotation.y += Math.min(delta, 0.1) * 0.01 * speed;
  });

  return (
    <instancedMesh ref={meshRef} args={[undefined, undefined, count]} frustumCulled={false}>
      <icosahedronGeometry args={[1, 0]} />
      <meshStandardMaterial color="#6d675e" roughness={0.96} metalness={0.04} />
    </instancedMesh>
  );
}

export function Scene() {
  const planets = BODIES.filter((body) => !body.parentId && body.id !== "sun");

  return (
    <>
      <color attach="background" args={["#050508"]} />
      <hemisphereLight args={["#151a28", "#09080a", 0.42]} />
      <ambientLight intensity={0.035} />
      <Starfield />
      <SimClock />
      <Sun />
      {ORBITING_BODIES.map((body) => (
        <OrbitTrail key={`trail-${body.id}`} body={body} />
      ))}
      {planets.map((body) => (
        <PlanetaryBody key={body.id} body={body} />
      ))}
      <AsteroidBelt />
      <CameraRig />
    </>
  );
}
