export function BootScreen() {
  return (
    <div className="flex h-dvh w-full flex-col items-center justify-center bg-background px-6 text-foreground">
      <p className="boot-title text-2xs font-medium uppercase tracking-label text-muted-foreground">Solar model</p>
      <h1 className="boot-title font-display text-5xl font-medium tracking-display stagger-1">Orrery</h1>
      <p className="boot-title mt-3 max-w-sm text-center text-sm text-muted-foreground stagger-2">
        Assembling the inner system…
      </p>
    </div>
  );
}
