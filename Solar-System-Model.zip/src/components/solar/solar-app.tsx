import { Canvas } from "@react-three/fiber";
import * as THREE from "three";
import { Scene } from "./scene";

export function SolarCanvas() {
  return (
    <Canvas
      className="touch-none h-full w-full"
      dpr={[1, 1.75]}
      camera={{ position: [22, 14, 32], fov: 42, near: 0.1, far: 250 }}
      gl={{
        antialias: true,
        alpha: false,
        powerPreference: "high-performance",
        toneMapping: THREE.ACESFilmicToneMapping,
        toneMappingExposure: 1.02,
      }}
      onCreated={({ gl }) => {
        gl.setClearColor("#050508", 1);
      }}
    >
      <Scene />
    </Canvas>
  );
}
