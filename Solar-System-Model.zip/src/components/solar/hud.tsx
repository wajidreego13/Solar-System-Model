import { Captions, CaptionsOff, Orbit, Pause, Play, Undo2, X } from "lucide-react";
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { BODY_BY_ID, PICKER_BODIES } from "@/lib/solar/bodies";
import { sim } from "@/lib/solar/sim";
import { MAX_SPEED, MIN_SPEED, useSolarStore } from "@/lib/solar/store";
import { cn } from "@/lib/utils";
import { LabelsOverlay } from "./labels-overlay";

function formatSpeed(speed: number) {
  return `${speed.toFixed(speed < 10 ? 2 : 1)}×`;
}

function useElapsedYears() {
  const [years, setYears] = useState(0);
  const paused = useSolarStore((state) => state.paused);

  useEffect(() => {
    const id = window.setInterval(() => {
      setYears(sim.elapsed / 12);
    }, paused ? 800 : 250);
    return () => window.clearInterval(id);
  }, [paused]);

  return years;
}

function IconSwap({
  active,
  ActiveIcon,
  InactiveIcon,
}: {
  active: boolean;
  ActiveIcon: typeof Pause;
  InactiveIcon: typeof Play;
}) {
  return (
    <span className="relative grid size-5 place-items-center">
      <span
        className={cn(
          "absolute inset-0 grid place-items-center transition-[opacity,transform,filter] duration-[var(--motion-fast)] ease-[var(--ease-out)]",
          active ? "scale-100 opacity-100 blur-0" : "scale-25 opacity-0 blur-[4px]",
        )}
      >
        <ActiveIcon className="size-4" strokeWidth={1.75} />
      </span>
      <span
        className={cn(
          "grid place-items-center transition-[opacity,transform,filter] duration-[var(--motion-fast)] ease-[var(--ease-out)]",
          active ? "scale-25 opacity-0 blur-[4px]" : "scale-100 opacity-100 blur-0",
        )}
      >
        <InactiveIcon className="size-4" strokeWidth={1.75} />
      </span>
    </span>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex flex-col gap-1">
      <span className="text-2xs font-medium uppercase tracking-label text-muted-foreground">{label}</span>
      <span className="font-mono text-sm tabular-nums text-foreground">{value}</span>
    </div>
  );
}

function InfoPanel() {
  const selectedId = useSolarStore((state) => state.selectedId);
  const select = useSolarStore((state) => state.select);
  if (!selectedId) return null;
  const body = BODY_BY_ID[selectedId];

  return (
    <aside
      className="panel-enter pointer-events-auto absolute inset-x-3 bottom-[7.5rem] z-10 max-h-[46vh] overflow-auto rounded-2xl bg-card p-4 shadow-[var(--shadow-panel)] md:inset-auto md:top-20 md:right-4 md:bottom-auto md:w-[22rem] md:max-h-[calc(100dvh-8rem)] md:rounded-xl md:p-5"
      aria-live="polite"
    >
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="text-2xs font-medium uppercase tracking-label text-muted-foreground">{body.kindLabel}</p>
          <h2 className="font-display text-3xl font-medium tracking-display text-foreground">{body.name}</h2>
        </div>
        <Button
          variant="ghost"
          size="icon-sm"
          className="shrink-0"
          aria-label="Close planet details"
          onClick={() => select(null)}
        >
          <X className="size-4" strokeWidth={1.75} />
        </Button>
      </div>
      <div className="mt-4 grid grid-cols-2 gap-x-4 gap-y-3">
        <Stat label="Distance" value={body.distanceAu} />
        <Stat label="Diameter" value={body.diameterKm} />
        <Stat label="Year" value={body.year} />
        <Stat label="Day" value={body.day} />
        <Stat label="Moons" value={body.moons} />
        <Stat label="Path" value={body.eccentricity > 0.05 ? "Eccentric" : "Near-circular"} />
      </div>
      <p className="stagger-2 mt-4 text-sm leading-normal text-muted-foreground">{body.summary}</p>
    </aside>
  );
}

function BodyList({ className }: { className?: string }) {
  const selectedId = useSolarStore((state) => state.selectedId);
  const select = useSolarStore((state) => state.select);

  return (
    <nav className={cn("flex gap-1", className)} aria-label="Solar system">
      {PICKER_BODIES.map((body) => {
        const active = selectedId === body.id;
        return (
          <button
            key={body.id}
            type="button"
            onClick={() => select(active ? null : body.id)}
            className={cn(
              "flex h-11 shrink-0 items-center gap-2 rounded-md px-2.5 text-left transition-[background-color,color,box-shadow] duration-[var(--motion-quick)] ease-[var(--ease-out)]",
              active ? "bg-muted text-foreground" : "text-muted-foreground hover:bg-muted/70 hover:text-foreground",
            )}
            aria-pressed={active}
            aria-label={`Focus ${body.name}`}
          >
            <span
              className="size-2 shrink-0 rounded-full"
              style={{ backgroundColor: body.swatch }}
              aria-hidden="true"
            />
            <span className="text-xs font-medium">{body.name}</span>
          </button>
        );
      })}
    </nav>
  );
}

export function Hud() {
  const paused = useSolarStore((state) => state.paused);
  const speed = useSolarStore((state) => state.speed);
  const showLabels = useSolarStore((state) => state.showLabels);
  const showTrails = useSolarStore((state) => state.showTrails);
  const selectedId = useSolarStore((state) => state.selectedId);
  const togglePaused = useSolarStore((state) => state.togglePaused);
  const setSpeed = useSolarStore((state) => state.setSpeed);
  const toggleLabels = useSolarStore((state) => state.toggleLabels);
  const toggleTrails = useSolarStore((state) => state.toggleTrails);
  const select = useSolarStore((state) => state.select);
  const years = useElapsedYears();

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      const target = event.target;
      if (target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement) return;
      if (event.code === "Space") {
        event.preventDefault();
        togglePaused();
      } else if (event.code === "Escape") {
        select(null);
      } else if (event.key === "[" || event.key === "-") {
        setSpeed(speed - 0.25);
      } else if (event.key === "]" || event.key === "=" || event.key === "+") {
        setSpeed(speed + 0.25);
      } else if (event.key === "l" || event.key === "L") {
        toggleLabels();
      } else if (event.key === "t" || event.key === "T") {
        toggleTrails();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [speed, togglePaused, setSpeed, toggleLabels, toggleTrails, select]);

  return (
    <div className="pointer-events-none absolute inset-0 z-10 text-foreground">
      <LabelsOverlay />
      <header className="pointer-events-auto absolute top-0 left-0 flex max-w-[min(100%,22rem)] flex-col gap-3 p-3 pt-[max(0.75rem,env(safe-area-inset-top))] md:p-4">
        <div className="rounded-xl bg-card/95 px-4 py-3 shadow-[var(--shadow-panel)]">
          <p className="text-2xs font-medium uppercase tracking-label text-muted-foreground">Solar model</p>
          <h1 className="font-display text-3xl font-medium tracking-display">Orrery</h1>
          <p className="mt-1 text-xs text-muted-foreground">A living model of the solar system.</p>
          <p className="mt-3 font-mono text-2xs tabular-nums text-muted-foreground">
            Elapsed {years.toFixed(2)} Earth years
            {paused ? " · Paused" : ""}
          </p>
        </div>
        <div className="hidden rounded-xl bg-card/95 p-2 shadow-[var(--shadow-panel)] md:block">
          <BodyList className="flex-col" />
        </div>
      </header>

      <InfoPanel />

      <div className="pointer-events-auto absolute right-3 top-[max(0.75rem,env(safe-area-inset-top))] md:right-4">
        <Button
          variant="outline"
          size="icon"
          className="bg-card/95"
          aria-label="Reset camera to the whole system"
          onClick={() => select(null)}
          disabled={!selectedId}
        >
          <Undo2 className="size-4" strokeWidth={1.75} />
        </Button>
      </div>

      <div className="pointer-events-auto absolute inset-x-0 bottom-0 pb-[max(0.75rem,env(safe-area-inset-bottom))]">
        <div className="mx-auto flex max-w-3xl flex-col gap-2 px-3 md:px-4">
          <div className="md:hidden overflow-x-auto rounded-xl bg-card/95 p-1 shadow-[var(--shadow-panel)]">
            <BodyList className="w-max" />
          </div>
          <div className="flex flex-col gap-2 rounded-xl bg-card/95 p-2 shadow-[var(--shadow-panel)] sm:flex-row sm:items-center sm:gap-3 sm:px-3">
            <div className="flex items-center gap-1">
              <Button
                variant="ghost"
                size="icon"
                aria-label={paused ? "Resume simulation" : "Pause simulation"}
                onClick={togglePaused}
              >
                <IconSwap active={!paused} ActiveIcon={Pause} InactiveIcon={Play} />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                aria-label={showLabels ? "Hide labels" : "Show labels"}
                onClick={toggleLabels}
              >
                <IconSwap active={showLabels} ActiveIcon={Captions} InactiveIcon={CaptionsOff} />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                aria-label={showTrails ? "Hide orbital trails" : "Show orbital trails"}
                onClick={toggleTrails}
                className={showTrails ? "text-foreground" : "text-muted-foreground"}
              >
                <Orbit className="size-4" strokeWidth={1.75} />
              </Button>
            </div>
            <div className="flex min-w-0 flex-1 items-center gap-3 px-2">
              <label
                htmlFor="sim-speed"
                className="shrink-0 text-2xs font-medium uppercase tracking-label text-muted-foreground"
              >
                Speed
              </label>
              <Slider
                id="sim-speed"
                min={MIN_SPEED}
                max={MAX_SPEED}
                step={0.25}
                value={[speed]}
                onValueChange={(value) => {
                  const next = value[0];
                  if (typeof next === "number") setSpeed(next);
                }}
                aria-label="Simulation speed"
              />
              <span className="w-12 shrink-0 text-right font-mono text-xs tabular-nums text-foreground">
                {formatSpeed(speed)}
              </span>
            </div>
          </div>
          <p className="hidden px-1 pb-1 text-center text-2xs text-muted-foreground md:block">
            Drag to orbit · Scroll to zoom · Click a world to inspect · Space pauses
          </p>
        </div>
      </div>
    </div>
  );
}
