import { useEffect, useRef } from "react";
import * as THREE from "three";
import { BODIES } from "@/lib/solar/bodies";
import { bodyWorld, labelWorldY, sim } from "@/lib/solar/sim";
import { useSolarStore } from "@/lib/solar/store";
import { cn } from "@/lib/utils";

const projected = new THREE.Vector3();
const camDir = new THREE.Vector3();
const toPoint = new THREE.Vector3();

export function LabelsOverlay() {
  const showLabels = useSolarStore((state) => state.showLabels);
  const selectedId = useSolarStore((state) => state.selectedId);
  const hoveredId = useSolarStore((state) => state.hoveredId);
  const nodes = useRef<Record<string, HTMLDivElement | null>>({});

  useEffect(() => {
    if (!showLabels) return;
    let frame = 0;
    const tick = () => {
      const camera = sim.camera;
      if (camera) {
        camera.getWorldDirection(camDir);
        for (const body of BODIES) {
          const el = nodes.current[body.id];
          if (!el) continue;
          projected.copy(bodyWorld[body.id]);
          projected.y += labelWorldY(body);
          toPoint.copy(projected).sub(camera.position);
          if (toPoint.dot(camDir) < 0) {
            el.style.opacity = "0";
            continue;
          }
          projected.project(camera);
          if (projected.z > 1 || Math.abs(projected.x) > 1.15 || Math.abs(projected.y) > 1.15) {
            el.style.opacity = "0";
            continue;
          }
          const x = (projected.x * 0.5 + 0.5) * sim.width;
          const y = (-projected.y * 0.5 + 0.5) * sim.height;
          el.style.transform = `translate(-50%, -120%) translate(${x}px, ${y}px)`;
          el.style.opacity = "1";
        }
      }
      frame = window.requestAnimationFrame(tick);
    };
    frame = window.requestAnimationFrame(tick);
    return () => window.cancelAnimationFrame(frame);
  }, [showLabels]);

  if (!showLabels) return null;

  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden" aria-hidden="true">
      {BODIES.map((body) => (
        <div
          key={body.id}
          ref={(node) => {
            nodes.current[body.id] = node;
          }}
          className={cn(
            "absolute top-0 left-0 whitespace-nowrap text-2xs font-medium uppercase tracking-label transition-opacity duration-[var(--motion-quick)] ease-[var(--ease-out)]",
            selectedId === body.id || hoveredId === body.id
              ? "text-foreground"
              : "text-foreground/65",
          )}
          style={{ opacity: 0 }}
        >
          {body.name}
        </div>
      ))}
    </div>
  );
}
