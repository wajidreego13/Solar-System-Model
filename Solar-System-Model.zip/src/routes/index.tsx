import { createFileRoute } from "@tanstack/react-router";
import { type ComponentType, useEffect, useState } from "react";
import { Hud } from "@/components/solar/hud";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const [CanvasApp, setCanvasApp] = useState<ComponentType | null>(null);

  useEffect(() => {
    let cancelled = false;
    void import("@/components/solar/solar-app").then((mod) => {
      if (!cancelled) setCanvasApp(() => mod.SolarCanvas);
    });
    return () => {
      cancelled = true;
    };
  }, []);

  return (
    <main className="relative h-dvh w-full overflow-hidden bg-background text-foreground">
      {CanvasApp ? (
        <CanvasApp />
      ) : (
        <div className="absolute inset-0 grid place-items-center">
          <p className="boot-title text-sm text-muted-foreground">Assembling the inner system…</p>
        </div>
      )}
      <Hud />
    </main>
  );
}
