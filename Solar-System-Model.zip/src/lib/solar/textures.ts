import * as THREE from "three";

const textureCache = new Map<string, THREE.Texture>();

function hash(x: number, y: number) {
  const s = Math.sin(x * 127.1 + y * 311.7) * 43758.5453;
  return s - Math.floor(s);
}

function lerp(a: number, b: number, t: number) {
  return a + (b - a) * t;
}

function smoothNoise(x: number, y: number) {
  const ix = Math.floor(x);
  const iy = Math.floor(y);
  const fx = x - ix;
  const fy = y - iy;
  const u = fx * fx * (3 - 2 * fx);
  const v = fy * fy * (3 - 2 * fy);
  return lerp(
    lerp(hash(ix, iy), hash(ix + 1, iy), u),
    lerp(hash(ix, iy + 1), hash(ix + 1, iy + 1), u),
    v,
  );
}

function fbm(x: number, y: number, octaves = 5) {
  let value = 0;
  let amp = 0.5;
  for (let i = 0; i < octaves; i += 1) {
    value += amp * smoothNoise(x, y);
    x *= 2;
    y *= 2;
    amp *= 0.5;
  }
  return value;
}

function canvasTexture(
  width: number,
  height: number,
  paint: (ctx: CanvasRenderingContext2D, w: number, h: number) => void,
) {
  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext("2d", { alpha: true });
  if (!ctx) throw new Error("Canvas 2D unavailable");
  paint(ctx, width, height);
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.anisotropy = 4;
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.ClampToEdgeWrapping;
  texture.needsUpdate = true;
  return texture;
}

function fillNoise(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  color: (n: number, u: number, v: number) => [number, number, number],
  scale = 6,
) {
  const image = ctx.createImageData(w, h);
  const data = image.data;
  for (let y = 0; y < h; y += 1) {
    for (let x = 0; x < w; x += 1) {
      const u = x / w;
      const v = y / h;
      const n = fbm(u * scale, v * scale * 0.5);
      const [r, g, b] = color(n, u, v);
      const i = (y * w + x) * 4;
      data[i] = r;
      data[i + 1] = g;
      data[i + 2] = b;
      data[i + 3] = 255;
    }
  }
  ctx.putImageData(image, 0, 0);
}

function paintSun(ctx: CanvasRenderingContext2D, w: number, h: number) {
  fillNoise(
    ctx,
    w,
    h,
    (n) => {
      const t = n * n;
      return [255, lerp(170, 230, t), lerp(70, 140, t)];
    },
    14,
  );
}

function paintMercury(ctx: CanvasRenderingContext2D, w: number, h: number) {
  fillNoise(
    ctx,
    w,
    h,
    (n, _u, v) => {
      const polar = Math.abs(v - 0.5);
      const shade = lerp(78, 160, n) - polar * 18;
      return [shade, shade * 0.94, shade * 0.86];
    },
    18,
  );
  ctx.globalCompositeOperation = "multiply";
  for (let i = 0; i < 90; i += 1) {
    const x = hash(i, 2) * w;
    const y = hash(i, 9) * h;
    const r = 2 + hash(i, 4) * 9;
    ctx.fillStyle = `rgba(20,18,16,${0.12 + hash(i, 6) * 0.28})`;
    ctx.beginPath();
    ctx.ellipse(x, y, r, r * 0.7, 0, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.globalCompositeOperation = "source-over";
}

function paintVenus(ctx: CanvasRenderingContext2D, w: number, h: number) {
  fillNoise(
    ctx,
    w,
    h,
    (n, _u, v) => {
      const swirl = Math.sin((v + n * 0.2) * Math.PI * 8);
      const t = 0.55 + n * 0.3 + swirl * 0.08;
      return [lerp(190, 236, t), lerp(150, 210, t), lerp(90, 140, t)];
    },
    9,
  );
}

function paintEarth(ctx: CanvasRenderingContext2D, w: number, h: number) {
  const image = ctx.createImageData(w, h);
  const data = image.data;
  for (let y = 0; y < h; y += 1) {
    for (let x = 0; x < w; x += 1) {
      const u = x / w;
      const v = y / h;
      const n = fbm(u * 7, v * 4, 6);
      const warp = fbm(u * 3 + 8, v * 3, 3);
      const land = n > 0.52 - Math.sin(v * Math.PI) * 0.04 + (warp - 0.5) * 0.12;
      const ice = v < 0.08 + n * 0.04 || v > 0.92 - n * 0.04;
      let r: number;
      let g: number;
      let b: number;
      if (ice) {
        r = 232;
        g = 240;
        b = 248;
      } else if (land) {
        const arid = fbm(u * 10, v * 8);
        r = lerp(42, 150, arid);
        g = lerp(92, 140, arid);
        b = lerp(46, 70, arid);
      } else {
        const deep = fbm(u * 4, v * 4);
        r = lerp(8, 30, deep);
        g = lerp(40, 90, deep);
        b = lerp(90, 150, deep);
      }
      const cloud = fbm(u * 11 + 3, v * 6, 4);
      if (cloud > 0.62) {
        const a = (cloud - 0.62) * 1.6;
        r = lerp(r, 245, a);
        g = lerp(g, 248, a);
        b = lerp(b, 252, a);
      }
      const i = (y * w + x) * 4;
      data[i] = r;
      data[i + 1] = g;
      data[i + 2] = b;
      data[i + 3] = 255;
    }
  }
  ctx.putImageData(image, 0, 0);
}

function paintMoon(ctx: CanvasRenderingContext2D, w: number, h: number) {
  fillNoise(
    ctx,
    w,
    h,
    (n) => {
      const s = lerp(88, 196, n);
      return [s, s * 0.98, s * 0.92];
    },
    16,
  );
  ctx.globalCompositeOperation = "multiply";
  for (let i = 0; i < 70; i += 1) {
    const x = hash(i, 1) * w;
    const y = hash(i, 4) * h;
    const r = 2 + hash(i, 8) * 12;
    ctx.fillStyle = `rgba(30,28,26,${0.1 + hash(i, 5) * 0.25})`;
    ctx.beginPath();
    ctx.ellipse(x, y, r, r * 0.72, 0, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.globalCompositeOperation = "source-over";
}

function paintMars(ctx: CanvasRenderingContext2D, w: number, h: number) {
  fillNoise(
    ctx,
    w,
    h,
    (n, _u, v) => {
      const ice = v < 0.07 + n * 0.03 || v > 0.93 - n * 0.03;
      if (ice) return [236, 238, 242];
      const rust = lerp(0.35, 1, n);
      return [lerp(90, 196, rust), lerp(42, 96, rust), lerp(28, 58, rust)];
    },
    11,
  );
}

function paintBands(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  palette: [number, number, number][],
  turbulence = 1,
  spot?: { v: number; u: number; rw: number; rh: number; color: [number, number, number] },
) {
  const image = ctx.createImageData(w, h);
  const data = image.data;
  for (let y = 0; y < h; y += 1) {
    for (let x = 0; x < w; x += 1) {
      const u = x / w;
      const v = y / h;
      const n = fbm(u * 8, v * 14, 4);
      const band = (v * palette.length + n * 0.35 * turbulence + Math.sin(u * Math.PI * 2 + n) * 0.08) %
        palette.length;
      const i0 = Math.floor(band);
      const i1 = (i0 + 1) % palette.length;
      const t = band - i0;
      const c0 = palette[i0] ?? palette[0];
      const c1 = palette[i1] ?? palette[0];
      let r = lerp(c0[0], c1[0], t);
      let g = lerp(c0[1], c1[1], t);
      let b = lerp(c0[2], c1[2], t);
      if (spot) {
        const du = (u - spot.u) / spot.rw;
        const dv = (v - spot.v) / spot.rh;
        if (du * du + dv * dv < 1) {
          const k = 1 - (du * du + dv * dv);
          r = lerp(r, spot.color[0], k);
          g = lerp(g, spot.color[1], k);
          b = lerp(b, spot.color[2], k);
        }
      }
      const i = (y * w + x) * 4;
      data[i] = r;
      data[i + 1] = g;
      data[i + 2] = b;
      data[i + 3] = 255;
    }
  }
  ctx.putImageData(image, 0, 0);
}

function paintJupiter(ctx: CanvasRenderingContext2D, w: number, h: number) {
  paintBands(
    ctx,
    w,
    h,
    [
      [214, 176, 128],
      [186, 140, 96],
      [232, 208, 168],
      [168, 122, 86],
      [206, 166, 118],
      [150, 108, 78],
    ],
    1.2,
    { u: 0.62, v: 0.62, rw: 0.08, rh: 0.055, color: [176, 78, 48] },
  );
}

function paintSaturn(ctx: CanvasRenderingContext2D, w: number, h: number) {
  paintBands(
    ctx,
    w,
    h,
    [
      [232, 214, 170],
      [214, 190, 140],
      [240, 226, 190],
      [198, 176, 128],
      [226, 208, 164],
    ],
    0.7,
  );
}

function paintUranus(ctx: CanvasRenderingContext2D, w: number, h: number) {
  fillNoise(
    ctx,
    w,
    h,
    (n, _u, v) => {
      const polar = Math.abs(v - 0.5);
      const t = n * 0.25 + polar * 0.15;
      return [lerp(140, 186, t), lerp(196, 226, t), lerp(200, 228, t)];
    },
    5,
  );
}

function paintNeptune(ctx: CanvasRenderingContext2D, w: number, h: number) {
  paintBands(
    ctx,
    w,
    h,
    [
      [46, 86, 176],
      [62, 110, 196],
      [38, 72, 150],
      [86, 132, 210],
      [40, 78, 160],
    ],
    0.9,
    { u: 0.7, v: 0.58, rw: 0.07, rh: 0.05, color: [18, 36, 80] },
  );
}

function paintPluto(ctx: CanvasRenderingContext2D, w: number, h: number) {
  fillNoise(
    ctx,
    w,
    h,
    (n, u, v) => {
      const heart = Math.hypot((u - 0.42) / 0.16, (v - 0.48) / 0.12) < 1;
      if (heart) return [232, 214, 206];
      const t = n;
      return [lerp(96, 186, t), lerp(78, 150, t), lerp(64, 122, t)];
    },
    8,
  );
}

const painters: Record<string, (ctx: CanvasRenderingContext2D, w: number, h: number) => void> = {
  sun: paintSun,
  mercury: paintMercury,
  venus: paintVenus,
  earth: paintEarth,
  moon: paintMoon,
  mars: paintMars,
  jupiter: paintJupiter,
  saturn: paintSaturn,
  uranus: paintUranus,
  neptune: paintNeptune,
  pluto: paintPluto,
};

export function getBodyTexture(id: string): THREE.Texture {
  const cached = textureCache.get(id);
  if (cached) return cached;
  const paint = painters[id] ?? paintMercury;
  const large = id === "earth" || id === "jupiter" || id === "sun";
  const texture = canvasTexture(large ? 1024 : 512, large ? 512 : 256, paint);
  textureCache.set(id, texture);
  return texture;
}

export function getGlowTexture() {
  const cached = textureCache.get("glow");
  if (cached) return cached;
  const texture = canvasTexture(256, 256, (ctx, w, h) => {
    const gradient = ctx.createRadialGradient(w / 2, h / 2, 0, w / 2, h / 2, w / 2);
    gradient.addColorStop(0, "rgba(255, 244, 214, 0.95)");
    gradient.addColorStop(0.18, "rgba(255, 196, 110, 0.45)");
    gradient.addColorStop(0.42, "rgba(255, 140, 48, 0.12)");
    gradient.addColorStop(1, "rgba(255, 120, 20, 0)");
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, w, h);
  });
  texture.wrapS = THREE.ClampToEdgeWrapping;
  textureCache.set("glow", texture);
  return texture;
}

export function getRingTexture() {
  const cached = textureCache.get("saturn-rings");
  if (cached) return cached;
  const texture = canvasTexture(8, 512, (ctx, w, h) => {
    const image = ctx.createImageData(w, h);
    const data = image.data;
    for (let y = 0; y < h; y += 1) {
      const v = y / h;
      const cassini = v > 0.46 && v < 0.52;
      const gap2 = v > 0.78 && v < 0.8;
      const band = 0.35 + Math.sin(v * Math.PI * 48) * 0.18 + fbm(2, v * 20, 3) * 0.25;
      const alpha = cassini || gap2 ? 0 : Math.max(0, Math.min(1, band));
      const shade = 180 + Math.sin(v * 30) * 30;
      for (let x = 0; x < w; x += 1) {
        const i = (y * w + x) * 4;
        data[i] = shade;
        data[i + 1] = shade * 0.92;
        data[i + 2] = shade * 0.78;
        data[i + 3] = alpha * 220;
      }
    }
    ctx.putImageData(image, 0, 0);
  });
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.ClampToEdgeWrapping;
  textureCache.set("saturn-rings", texture);
  return texture;
}
