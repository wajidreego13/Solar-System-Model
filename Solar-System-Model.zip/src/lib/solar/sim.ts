import * as THREE from "three";
import { BODIES, type BodyDef, type BodyId } from "./bodies";

const AXIS_X = new THREE.Vector3(1, 0, 0);
const scratch = new THREE.Vector3();

export const sim = {
  elapsed: 0,
  camera: null as THREE.Camera | null,
  width: 1,
  height: 1,
};

export const bodyWorld = Object.fromEntries(BODIES.map((body) => [body.id, new THREE.Vector3()])) as Record<
  BodyId,
  THREE.Vector3
>;

export function orbitPosition(body: BodyDef, elapsed: number, target: THREE.Vector3) {
  if (body.orbitRadius <= 0) {
    target.set(0, 0, 0);
    return;
  }
  const anomaly = (elapsed / body.orbitPeriod) * Math.PI * 2;
  const e = body.eccentricity;
  const radius = (body.orbitRadius * (1 - e * e)) / (1 + e * Math.cos(anomaly));
  target.set(Math.cos(anomaly) * radius, 0, Math.sin(anomaly) * radius);
  if (body.inclination !== 0) {
    target.applyAxisAngle(AXIS_X, body.inclination);
  }
}

export function updateBodyWorld(elapsed: number) {
  for (const body of BODIES) {
    const target = bodyWorld[body.id];
    if (body.parentId) {
      const parent = bodyWorld[body.parentId];
      const anomaly = (elapsed / body.orbitPeriod) * Math.PI * 2;
      const e = body.eccentricity;
      const radius = (body.orbitRadius * (1 - e * e)) / (1 + e * Math.cos(anomaly));
      scratch.set(Math.cos(anomaly) * radius, 0, Math.sin(anomaly) * radius);
      if (body.inclination !== 0) scratch.applyAxisAngle(AXIS_X, body.inclination);
      target.copy(parent).add(scratch);
    } else {
      orbitPosition(body, elapsed, target);
    }
  }
}

export function orbitCurve(body: BodyDef, segments = 160): THREE.Vector3[] {
  const points: THREE.Vector3[] = [];
  for (let i = 0; i <= segments; i += 1) {
    const t = (i / segments) * body.orbitPeriod;
    const point = new THREE.Vector3();
    orbitPosition(body, t, point);
    points.push(point);
  }
  return points;
}

export function focusDistance(body: BodyDef) {
  if (body.id === "sun") return 11.5;
  const ring = body.hasRings ? (body.ringOuter ?? 2) * body.radius : body.radius;
  return ring * 5.4 + 2.15;
}

export function labelWorldY(body: BodyDef) {
  const ringExtent = body.hasRings ? (body.ringOuter ?? 2.2) : 1;
  return body.radius * ringExtent + 0.4;
}
