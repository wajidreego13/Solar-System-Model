import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";
import type { BodyId } from "./bodies";

interface SolarState {
  paused: boolean;
  speed: number;
  selectedId: BodyId | null;
  hoveredId: BodyId | null;
  showLabels: boolean;
  showTrails: boolean;
  setPaused: (paused: boolean) => void;
  togglePaused: () => void;
  setSpeed: (speed: number) => void;
  select: (id: BodyId | null) => void;
  setHovered: (id: BodyId | null) => void;
  toggleLabels: () => void;
  toggleTrails: () => void;
}

export const MIN_SPEED = 0.25;
export const MAX_SPEED = 12;

const noopStorage = {
  getItem: () => null,
  setItem: () => {},
  removeItem: () => {},
};

export const useSolarStore = create<SolarState>()(
  persist(
    (set) => ({
      paused: false,
      speed: 1,
      selectedId: null,
      hoveredId: null,
      showLabels: true,
      showTrails: true,
      setPaused: (paused) => set({ paused }),
      togglePaused: () => set((state) => ({ paused: !state.paused })),
      setSpeed: (speed) => set({ speed: Math.min(MAX_SPEED, Math.max(MIN_SPEED, speed)) }),
      select: (selectedId) => set({ selectedId }),
      setHovered: (hoveredId) => set({ hoveredId }),
      toggleLabels: () => set((state) => ({ showLabels: !state.showLabels })),
      toggleTrails: () => set((state) => ({ showTrails: !state.showTrails })),
    }),
    {
      name: "orrery-prefs-v1",
      storage: createJSONStorage(() => (typeof window === "undefined" ? noopStorage : localStorage)),
      partialize: (state) => ({
        speed: state.speed,
        showLabels: state.showLabels,
        showTrails: state.showTrails,
      }),
    },
  ),
);
