export type BodyId =
  | "sun"
  | "mercury"
  | "venus"
  | "earth"
  | "moon"
  | "mars"
  | "jupiter"
  | "saturn"
  | "uranus"
  | "neptune"
  | "pluto";

export type BodyKind = "star" | "terrestrial" | "gas-giant" | "ice-giant" | "dwarf" | "moon";

export interface BodyDef {
  id: BodyId;
  name: string;
  kind: BodyKind;
  kindLabel: string;
  radius: number;
  orbitRadius: number;
  eccentricity: number;
  inclination: number;
  orbitPeriod: number;
  spin: number;
  axialTilt: number;
  swatch: string;
  roughness: number;
  metalness: number;
  emissive?: string;
  emissiveIntensity?: number;
  atmosphereColor?: string;
  atmosphereScale?: number;
  hasRings?: boolean;
  ringInner?: number;
  ringOuter?: number;
  parentId?: BodyId;
  inPicker: boolean;
  distanceAu: string;
  diameterKm: string;
  year: string;
  day: string;
  moons: string;
  summary: string;
}

export const BODIES: BodyDef[] = [
  {
    id: "sun",
    name: "Sun",
    kind: "star",
    kindLabel: "G-type star",
    radius: 2.45,
    orbitRadius: 0,
    eccentricity: 0,
    inclination: 0,
    orbitPeriod: 1,
    spin: 0.14,
    axialTilt: 0.13,
    swatch: "#f3d7a1",
    roughness: 1,
    metalness: 0,
    emissive: "#ffd59a",
    emissiveIntensity: 1.4,
    inPicker: true,
    distanceAu: "—",
    diameterKm: "1,392,700 km",
    year: "—",
    day: "25.4 days (eq.)",
    moons: "—",
    summary:
      "A G-type main-sequence star holding more than 99% of the system's mass. Its gravity writes every orbit in this model.",
  },
  {
    id: "mercury",
    name: "Mercury",
    kind: "terrestrial",
    kindLabel: "Terrestrial planet",
    radius: 0.22,
    orbitRadius: 5.15,
    eccentricity: 0.21,
    inclination: 0.12,
    orbitPeriod: 5.2,
    spin: 0.22,
    axialTilt: 0.03,
    swatch: "#9a9086",
    roughness: 0.92,
    metalness: 0.08,
    inPicker: true,
    distanceAu: "0.39 AU",
    diameterKm: "4,879 km",
    year: "88 days",
    day: "59 days",
    moons: "0",
    summary:
      "The innermost world. A cratered, airless body that bakes by day and freezes by night, racing the Sun on a markedly eccentric path.",
  },
  {
    id: "venus",
    name: "Venus",
    kind: "terrestrial",
    kindLabel: "Terrestrial planet",
    radius: 0.38,
    orbitRadius: 7.35,
    eccentricity: 0.007,
    inclination: 0.059,
    orbitPeriod: 8.6,
    spin: -0.07,
    axialTilt: 3.1,
    swatch: "#d9c18a",
    roughness: 0.78,
    metalness: 0,
    atmosphereColor: "#e6d7a8",
    atmosphereScale: 1.08,
    inPicker: true,
    distanceAu: "0.72 AU",
    diameterKm: "12,104 km",
    year: "225 days",
    day: "243 days (rev.)",
    moons: "0",
    summary:
      "Earth's dense twin, wrapped in a runaway greenhouse. It spins slowly backwards beneath a pale sulfuric haze.",
  },
  {
    id: "earth",
    name: "Earth",
    kind: "terrestrial",
    kindLabel: "Terrestrial planet",
    radius: 0.4,
    orbitRadius: 10,
    eccentricity: 0.017,
    inclination: 0,
    orbitPeriod: 12,
    spin: 0.58,
    axialTilt: 0.41,
    swatch: "#6ea0d0",
    roughness: 0.62,
    metalness: 0.04,
    atmosphereColor: "#8ec5ff",
    atmosphereScale: 1.07,
    inPicker: true,
    distanceAu: "1.00 AU",
    diameterKm: "12,742 km",
    year: "365.25 days",
    day: "23.9 hours",
    moons: "1",
    summary:
      "The only world known to harbor life. Liquid oceans, wandering continents, and a thin blue atmosphere catch the Sun.",
  },
  {
    id: "moon",
    name: "Moon",
    kind: "moon",
    kindLabel: "Natural satellite",
    radius: 0.12,
    orbitRadius: 1.05,
    eccentricity: 0.055,
    inclination: 0.09,
    orbitPeriod: 3.4,
    spin: 0.18,
    axialTilt: 0.12,
    swatch: "#c5c1b8",
    roughness: 0.95,
    metalness: 0,
    parentId: "earth",
    inPicker: false,
    distanceAu: "384,400 km",
    diameterKm: "3,475 km",
    year: "27.3 days",
    day: "27.3 days",
    moons: "—",
    summary:
      "Earth's companion, tidally locked so the same face always watches home. Its pull lifts the oceans twice a day.",
  },
  {
    id: "mars",
    name: "Mars",
    kind: "terrestrial",
    kindLabel: "Terrestrial planet",
    radius: 0.28,
    orbitRadius: 13.15,
    eccentricity: 0.093,
    inclination: 0.032,
    orbitPeriod: 18.2,
    spin: 0.54,
    axialTilt: 0.44,
    swatch: "#c48462",
    roughness: 0.88,
    metalness: 0.02,
    atmosphereColor: "#d9a078",
    atmosphereScale: 1.05,
    inPicker: true,
    distanceAu: "1.52 AU",
    diameterKm: "6,779 km",
    year: "687 days",
    day: "24.6 hours",
    moons: "2",
    summary:
      "A cold desert stained with iron oxide. Polar ice, ancient riverbeds, and the tallest volcano in the system remain.",
  },
  {
    id: "jupiter",
    name: "Jupiter",
    kind: "gas-giant",
    kindLabel: "Gas giant",
    radius: 1.18,
    orbitRadius: 19.8,
    eccentricity: 0.049,
    inclination: 0.023,
    orbitPeriod: 44,
    spin: 1.15,
    axialTilt: 0.05,
    swatch: "#d0b48a",
    roughness: 0.55,
    metalness: 0,
    inPicker: true,
    distanceAu: "5.20 AU",
    diameterKm: "139,820 km",
    year: "11.9 years",
    day: "9.9 hours",
    moons: "95",
    summary:
      "The system's shield. A hydrogen-helium giant whose storms have lasted centuries, including the Great Red Spot.",
  },
  {
    id: "saturn",
    name: "Saturn",
    kind: "gas-giant",
    kindLabel: "Gas giant",
    radius: 1.02,
    orbitRadius: 25.8,
    eccentricity: 0.057,
    inclination: 0.043,
    orbitPeriod: 66,
    spin: 1.02,
    axialTilt: 0.47,
    swatch: "#e0d0a8",
    roughness: 0.58,
    metalness: 0,
    hasRings: true,
    ringInner: 1.35,
    ringOuter: 2.35,
    inPicker: true,
    distanceAu: "9.58 AU",
    diameterKm: "116,460 km",
    year: "29.5 years",
    day: "10.7 hours",
    moons: "146",
    summary:
      "Pale, banded, and famously ringed. Ice and rock orbit in a paper-thin disk that catches sunlight like a blade.",
  },
  {
    id: "uranus",
    name: "Uranus",
    kind: "ice-giant",
    kindLabel: "Ice giant",
    radius: 0.62,
    orbitRadius: 32.2,
    eccentricity: 0.046,
    inclination: 0.013,
    orbitPeriod: 90,
    spin: -0.72,
    axialTilt: 1.71,
    swatch: "#9fd4d8",
    roughness: 0.48,
    metalness: 0.02,
    atmosphereColor: "#b7e4e8",
    atmosphereScale: 1.05,
    inPicker: true,
    distanceAu: "19.2 AU",
    diameterKm: "50,724 km",
    year: "84 years",
    day: "17.2 hours",
    moons: "28",
    summary:
      "An ice giant rolling on its side. A 98° tilt turns seasons into decades of day and decades of night.",
  },
  {
    id: "neptune",
    name: "Neptune",
    kind: "ice-giant",
    kindLabel: "Ice giant",
    radius: 0.6,
    orbitRadius: 38.4,
    eccentricity: 0.011,
    inclination: 0.031,
    orbitPeriod: 112,
    spin: 0.78,
    axialTilt: 0.49,
    swatch: "#4d7fd0",
    roughness: 0.46,
    metalness: 0.02,
    atmosphereColor: "#6ea0e8",
    atmosphereScale: 1.05,
    inPicker: true,
    distanceAu: "30.1 AU",
    diameterKm: "49,244 km",
    year: "165 years",
    day: "16.1 hours",
    moons: "16",
    summary:
      "The farthest planet, and the windiest. Methane stains it a deep blue; a dark storm still rides its southern haze.",
  },
  {
    id: "pluto",
    name: "Pluto",
    kind: "dwarf",
    kindLabel: "Dwarf planet",
    radius: 0.16,
    orbitRadius: 44.5,
    eccentricity: 0.25,
    inclination: 0.3,
    orbitPeriod: 142,
    spin: -0.2,
    axialTilt: 2.12,
    swatch: "#cbb8a4",
    roughness: 0.9,
    metalness: 0,
    inPicker: true,
    distanceAu: "39.5 AU",
    diameterKm: "2,377 km",
    year: "248 years",
    day: "6.4 days",
    moons: "5",
    summary:
      "A heart-marked wanderer of the Kuiper belt. Its tilted, eccentric orbit still carries it inside Neptune's path.",
  },
];

export const BODY_BY_ID = Object.fromEntries(BODIES.map((body) => [body.id, body])) as Record<
  BodyId,
  BodyDef
>;

export const PICKER_BODIES = BODIES.filter((body) => body.inPicker);

export const ORBITING_BODIES = BODIES.filter((body) => body.orbitRadius > 0 && !body.parentId);
